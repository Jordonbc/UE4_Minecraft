/*
 SimplexNoise 1.0.0
 -----
 DevDad - Afan Olovcic @ art-and-code.com - 08/12/2015
*/
#pragma once

#include "Engine.h"
#include "SimplexNoiseClasses.h"

//DECLARE_LOG_CATEGORY_EXTERN(Victory, Log, All);
