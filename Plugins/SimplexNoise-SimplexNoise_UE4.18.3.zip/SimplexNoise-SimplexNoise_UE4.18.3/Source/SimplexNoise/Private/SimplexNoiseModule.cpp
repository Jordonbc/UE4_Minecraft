/*
 SimplexNoise 1.0.0
 -----
 DevDad - Afan Olovcic @ art-and-code.com - 08/12/2015
*/
#include "SimplexNoisePrivatePCH.h"

//DEFINE_LOG_CATEGORY(Victory)

IMPLEMENT_MODULE(FDefaultGameModuleImpl, SimplexNoise);